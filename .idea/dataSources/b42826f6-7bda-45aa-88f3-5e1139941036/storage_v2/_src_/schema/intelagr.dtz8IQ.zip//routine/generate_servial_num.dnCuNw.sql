create procedure generate_servial_num(IN bizType CHAR(2), IN servial_num CHAR(20))
BEGIN
  DECLARE currentDate varchar (15);
  DECLARE oldNo int DEFAULT 0;
  SELECT DATE_FORMAT(NOW(), '%Y%m%d') INTO currentDate;
 SELECT IFNULL(PTNo, '') INTO  oldNo FROM b_servial_num ;  
  if bizType = 'PT' then
     SELECT IFNULL(PTNo, 0) INTO  oldNo FROM b_servial_num ; 
     update b_servial_num set PTNo=PTNo+1 where id=1;
  elseif bizType = 'TX' then
      SELECT IFNULL(TXNo, 0) INTO  oldNo FROM b_servial_num ; 
      update b_servial_num set TXNo=TXNo+1 where id=1;
  elseif bizType = 'SL' then
      SELECT IFNULL(SLNo, 0) INTO  oldNo FROM b_servial_num ; 
      update b_servial_num set SLNo=SLNo+1 where id=1;
  elseif bizType = 'TR' then
      SELECT IFNULL(TRNo, 0) INTO  oldNo FROM b_servial_num ; 
      update b_servial_num set TRNo=TRNo+1 where id=1;
  elseif bizType = 'BG' then
      SELECT IFNULL(BGNo, 0) INTO  oldNo FROM b_servial_num ; 
      update b_servial_num set BGNo=BGNo+1 where id=1;
  end if;
  SET servial_num = CONCAT(bizType,currentDate,  LPAD(oldNo+1,6,0));
  SELECT servial_num;
END;

